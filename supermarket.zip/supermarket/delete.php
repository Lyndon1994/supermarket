<?php 
header('Content-Type:text/html;charset=UTF-8');
if(!empty($_GET['id'])){
	require_once 'connect.php';
	$query="delete from goods where goods_id=".$_GET['id'];
	$query2="delete from trades where goods_id=".$_GET['id'];
	$result=$mysql->query($query);
	$result2=$mysql->query($query2);
	if ($result&&$result2) {
			echo "<script>alert('删除成功！');
			window.location.href='./';</script>";
		}else{
			echo "<script>window.location.href='error.php?num=1';</script>";
		}
		$mysql->close();
}

?>