<?php session_start();?>
<?php 
require_once 'connect.php';
if (empty($_SESSION['name'])) {
  echo "<script>window.location.href='login.php';</script>";
}
 ?>
 <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <title>库存管理系统</title>

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/search.js" type="text/javascript"></script>
    
     <link href="css/mine.css" rel="stylesheet" type="text/css">
    
  </head>

