<?php 
	@$mysql = mysqli_connect('localhost','root','','supermarket') or die("Error " . mysqli_error($mysql)."<script>window.location.href='error.php?num=1';</script>");
	//@$mysql = mysqli_connect('SAE_MYSQL_HOST_M:SAE_MYSQL_PORT','SAE_MYSQL_USER','SAE_MYSQL_PASS','supermarket') or die("Error " . mysqli_error($mysql)."<script>window.location.href='error.php?num=1';</script>");
 ?>