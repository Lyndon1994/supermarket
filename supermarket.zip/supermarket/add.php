<?php require_once 'head.php'; ?>

<script>
$("title").html("添加商品");
$(document).ready(function(){
  $(document).click(function(){
    $(".list-group").click(function(){
      return;
    })
    $(".list-group").hide();
  });
});
</script>

  <body>
<?php 
  if ((!empty($_POST['goods_id']))&&(!empty($_POST['name']))&&(!empty($_POST['class']))) {
   // require_once 'connect.php';
    $query="select * from goods where goods_id=".$_POST['goods_id'];
    $result=$mysql->query($query);
    if($result&&$result->num_rows>0) echo "<script>alert('此商品ID已存在！添加失败！');</script>";//查询出错

    $brief=empty($_POST['brief'])?NULL:$_POST['brief'];
    $safe_inventory=empty($_POST['safe_inventory'])?0:$_POST['safe_inventory'];
    $class_id=substr($_POST['goods_id'], 0 , 1);
    $query="insert into goods values('".$_POST['goods_id']."','".$_POST['name']."','".$brief."','".$class_id."','".$_POST['class']."','0','".$safe_inventory."',NOW(),NOW())";
    $result=$mysql->query($query);
    if ($result) {
      echo "<script>window.location.href='show.php?id=".$_POST['goods_id']."';</script>";
    }else{
      echo "添加失败！";
    }
    $mysql->close();
  }
  ?>
<div class="container-fluid">
  <div class="row-fluid">
      <ul class="nav nav-tabs nav-justified">
        <li role="presentation"><a href="./">超市库存管理系统</a></li>
      </ul> 

      <div class="page-header text-center">
        <h1>添加商品</h1>
      </div>
      
      <form action="add.php" method="post">
        <div class="form-group">
          <label>商品ID</label>
          <input type="text" class="form-control" placeholder="输入商品ID" name="goods_id">
        </div>
        <div class="form-group">
          <label>商品名称</label>
          <input type="text" class="form-control" placeholder="输入商品名称" name="name">
        </div>
        <div class="form-group">
            <label>商品类别</label>
            <select class="form-control" name="class">
                <option>水产类</option>
                <option>电器类</option>
                <option>肉食类</option>
                <option>鲜果类</option>
                <option>干品类</option>
                <option>服装类</option>
              </select>
          </div>
        <div class="form-group">
          <label>安全库存</label>
          <input type="text" class="form-control" placeholder="输入商品安全库存" name="safe_inventory">
        </div>
        <div class="form-group">
          <label>商品简介</label>
          <textarea class="form-control" rows="3" name="brief"></textarea>
        </div>
        <button type="submit" class="btn btn-default">提交</button>
      </form>
  </div>

</div>
<?php require_once 'foot.php'; ?>
