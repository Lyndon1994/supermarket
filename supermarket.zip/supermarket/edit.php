<!DOCTYPE html>
<meta charset="utf-8">
<?php 

 if ((!empty($_POST['goods_id']))) {
    require_once 'connect.php';

    $brief=empty($_POST['brief'])?NULL:$_POST['brief'];
    $safe_inventory=empty($_POST['safe_inventory'])?0:$_POST['safe_inventory'];
    $class_id=substr($_POST['goods_id'], 0 , 1);
    $query="update goods set name= '".$_POST['name']."',brief='".$brief."', inventory=".$_POST['inventory'].",safe_inventory=".$safe_inventory.", updated_at=NOW() where goods_id=".$_POST['goods_id'];

    $result=$mysql->query($query);
    if ($result) {
      echo "<script>alert('保存成功！');
      window.location.href='show.php?id=".$_POST['goods_id']."';</script>";
    }else{
      echo "<script>alert('保存失败！');
      window.location.href='show.php?id=".$_POST['goods_id']."';</script>";
    }
    $mysql->close();
   }

  ?>