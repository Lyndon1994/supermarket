<?php require_once 'head.php'; ?>

<?php 
  /**
  *根据url判断是出库还是入库
  */
  $trade="";
  if (!empty($_GET['trade'])) {
      if ($_GET['trade']=="in") {
        $trade="入库";
      }else{
        $trade="出库";
      }
  }else{
    echo "<script>window.location.href='error.php?num=2';</script>";
  }
 ?>
<script>
$("title").html("商品<?php echo $trade; ?>");
$(document).ready(function(){
  $(document).click(function(){
    $(".list-group").click(function(){
      return;
    })
    $(".list-group").hide();
  });
});
</script>

  <body>
<?php 


  if ((!empty($_POST['goods_id']))&&(!empty($_POST['number']))&&$_POST['number']>0) {
    $query="select * from goods where goods_id=".$_POST['goods_id'];
    $result=$mysql->query($query);
    if(!$result||$result->num_rows<1) echo "<script>window.location.href='error.php?num=3';</script>";//查询出错

    $remarks=empty($_POST['remarks'])?NULL:$_POST['remarks'];
    date_default_timezone_set('PRC');
    $time=date('Y-m-d H:i:s');
    if ($_GET['trade']=="in") {
        $number=$_POST['number'];
      }else{
        $number=(-$_POST['number']);
      }
    $row=$result->fetch_assoc();
	if ($_GET['trade']=="out"&&$row['inventory']<$_POST['number']) {
        	echo "<script>alert('库存量不足！');window.location.href=location;</script>";
    }else{
	    $query="insert into trades values(NULL,'".$_POST['goods_id']."','".$number."','".$remarks."','".$time."','".$time."')";
	    $update="update goods set inventory=(inventory+".$number.") where goods_id=".$_POST['goods_id'];
	    $result=$mysql->query($query);
	    $updateResult=$mysql->query($update);
	    if ($result&&$updateResult) {
	      echo "<script>alert('提交成功！');
	      window.location.href='show.php?id=".$_POST['goods_id']."';</script>";
	      
	    }else{
	      echo "alert('提交失败!');";
	    }
	    $mysql->close();	
    }
    
  }
  ?>

<div class="container-fluid">
  <div class="row-fluid">
    <ul class="nav nav-tabs nav-justified">
        <li role="presentation"><a href="./">超市库存管理系统</a></li>
      </ul> 
      <div class="page-header text-center">

        <h1>商品<?php echo $trade; ?></h1>
      </div>
      <form action="trade.php?trade=<?php echo $_GET['trade']; ?>" method="post">
      <fieldset>
        <div class="form-group">
          <label>商品ID</label>
          <input type="text" id="goodsID" class="form-control" onkeyup="showResults(this.value,'showID')" placeholder="输入商品ID" name="goods_id" required autofocus>
          <ul class="list-group" id="showID" style="position:absolute; z-index: 1;"></ul>
          
        </div>
        <div class="form-group">
          <label>商品名称</label>
          <input type="text" id="goodsName" class="form-control" onkeyup="showResults(this.value,'showName')" placeholder="输入商品名称" name="name">
          <ul class="list-group" id="showName" style="position:absolute; z-index: 1;">
          </ul>
        </div>
        <div class="form-group">
          <label><?php echo $trade; ?>数量</label>
          <input type="number" class="form-control" id="number" placeholder="输入商品入库数量" name="number" onchange="is_positive(this.value)" required>
        </div>
        <div class="form-group">
          <label>日期时间</label>
          <input type="text" class="form-control" name="date" value="<?php date_default_timezone_set('PRC'); echo date('Y-m-d H:i:s'); ?>">
        </div>
        <div class="form-group">
          <label>备注</label>
          <textarea class="form-control" rows="3" name="remarks"></textarea>
        </div>
        <button type="submit" class="btn btn-default" id="submit">提交</button>
      </fieldset>
      </form>
  </div>
</div>


<script>
//确定出入库数量为正数
  function is_positive (num) {
    if ($("#number").val()<=0) {
      alert("请输入正数！");
      $("#submit").attr('disabled', 'disabled');
    }else{
      $("#submit").removeAttr('disabled');
    };
  }
</script>
<?php require_once 'foot.php'; ?>
