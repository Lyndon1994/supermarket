<?php require_once 'head.php'; ?>

<style> 

         /*body, html { height: 100%; width: 100%; } */

         body {
            /*display: -moz-box;
            display: -webkit-box;
            display: box;*/

            -moz-box-orient: horizontaerl; /* the default, so not really necessary here */
            -webkit-box-orient: horizontal;
            box-orient: horizontal;

            -moz-box-pack: center;
            -moz-box-align: center;

            -webkit-box-pack: center;
            -webkit-box-align: center;

            box-pack: center;
            box-align: center;
         }

         .box {
            /*background: #e3e3e3;*/
            /*border: 1px dashed #666;*/
            margin: 13px;
            width: 400px;
            height: 200px;
            cursor: pointer;
            position: relative;

            -webkit-transition: all 1s; 
            -moz-transition: all 1s;
            transition: all 1s; 
         }
          img{
            border: 0;
            width: 400px;
            height: 200px;
            box-shadow: 0px 5px 5px #888888;
          }
         .box::after {
            content: '';
            position: absolute;
            width: 70%;
            height: 10px;
            bottom: 0;
            left: 15%;
            z-index: -1;

            -webkit-box-shadow: 0 9px 20px rgba(0,0,0,.4);
            -moz-box-shadow: 0 9px 20px rgba(0,0,0,.4);
            box-shadow: 0 9px 20px rgba(0,0,0,.4);
         }

         .box > div {
            position: absolute;
            width: 100%; height: 100%;
            top: 0; left: 0;
            /*background: #e3e3e3;*/
            -webkit-transition: all .5s ease-in-out;
            -moz-transition: all .5s ease-in-out;
            transition: all .5s ease-in-out;

            font: 45px/200px bold helvetica, arial, sans-serif;
            text-align: center;
         }

         /* Make sure we see the front side first */
         .box > div:first-child {
            position: relative;
            z-index: 2;
         }

         .box:hover {
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            transform: rotateY(180deg);         
         }

         .box:hover > div:first-child {
            opacity: 0;
         }

         .box:hover div:last-child {
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            transform: rotateY(180deg);
         }

      </style>

  <body>
<div class="container-fluid">
  <div class="row-fluid">
     <a href="./"><div class="jumbotron">
      <h2 class="text-center">
       库存类别
      </h2>
    </div></a>
  </div>
    <?php 
      $year=(!empty($_GET['year']))?intval($_GET['year']):0;
      $month=(!empty($_GET['month']))?intval($_GET['month']):0;
      $date=$year."-".$month;
      //require_once 'connect.php';
      $query="select class_id,count(goods_id) from goods group by class_id order by class_id";
      $result=$mysql->query($query);
      $index=array();
      for ($i=1; $i <= $result->num_rows ; $i++) { 
        $row=$result->fetch_assoc();
        $index[$row['class_id']]=$row['count(goods_id)'];
      }
     ?>
    <div class="row text-center">
        <div class="col-md-2 box">
          <div><a href="statistics.php?class_id=1&date=<?php echo $date; ?>" role="button">
          <img src="./img/3.gif" alt="水产类">
          </a></div>
          <div>水产</div>
        </div>
        <div class="col-md-2 box">
          <div><a href="statistics.php?class_id=2&date=<?php echo $date; ?>" role="button">
          <img src="./img/2.gif" alt="电器类">
          </a></div><div>电器</div>
        </div>
        <div class="col-md-5 box">
          <div><a href="statistics.php?class_id=3&date=<?php echo $date; ?>" role="button">
          <img src="./img/5.gif" alt="肉食类">
          </a></div><div>肉食</div>
        </div>
        <div class="col-md-5 box">
          <div><a href="statistics.php?class_id=4&date=<?php echo $date; ?>" role="button">
          <img src="./img/4.gif" alt="鲜果类">
          </a></div><div>鲜果</div>
        </div>
        <div class="col-md-5 box">
          <div><a href="statistics.php?class_id=5&date=<?php echo $date; ?>" role="button">
          <img src="./img/1.gif" alt="干品类">
          </a></div><div>干品</div>
        </div>
        <div class="col-md-5 box">
          <div><a href="statistics.php?class_id=6&date=<?php echo $date; ?>" role="button">
          <img src="./img/6.gif" alt="服装类">
          </a></div><div>服装</div>
        </div>
    </div>
   
</div>

<?php require_once 'foot.php'; ?>
