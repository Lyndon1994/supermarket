<?php require_once 'head.php'; ?>


<?php 

  if ((!empty($_GET['id']))) {
   // require_once 'connect.php';
    $query="select * from goods where goods_id=".$_GET['id'];
    if(!$query) echo "<script>window.location.href='error.php?num=1';</script>";
	$result=$mysql->query($query);

	$row=$result->fetch_assoc();
?> 
<script>
$("title").html("<?php echo $row['name']; ?>");
</script>


  <body>
 
<div class="container-fluid">
	<div class="row-fluid">
		<div class="span12">
			
	<ul class="nav nav-tabs nav-justified">
        <li role="presentation"><a href="./trade.php?trade=in">入库</a></li>
        <li role="presentation"><a href="./">超市库存管理系统</a></li>
        <li role="presentation"><a href="./trade.php?trade=out">出库</a></li>
      </ul>
			<h1 class="text-center">
				<?php echo $row['name']; ?>
			</h1>

			<div class="jumbotron">
			<h2 class="text-center"><span class="label label-info">ID</span><?php echo $row['goods_id'] ?>
			<span class="label label-primary">类别</span><?php echo $row['class'] ?>
			<span class="label label-success">当前库存</span><?php echo $row['inventory'] ?>
			<span class="label label-warning">安全库存</span><?php echo $row['safe_inventory'] ?></h2>
			<div><span class="label label-default">简介</span><?php echo $row['brief'] ?></div>
			<div style="position:absolute;right:40px">
				<!-- <a class="btn btn-primary" href="edit.php?id=<?php echo $row['goods_id'] ?>" role="button">编辑</a> -->

				<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-edit-modal-sm">编辑</button>
				<div class="modal fade bs-edit-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-sm">
				    <div class="modal-content">
					    <div class="modal-header">
				          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				          <h4 class="modal-title" id="gridSystemModalLabel">修改商品信息</h4>
				        </div>
				       	<form action="edit.php?id=<?php echo $row['goods_id'] ?>" method="post">
				        <div class="modal-body">
					        <div class="form-group">
					          <label>商品ID</label>
					          <input type="text" class="form-control" name="goods_id" value="<?php echo $row['goods_id'] ?>" readonly>
					        </div>
					        <div class="form-group">
					          <label>商品名称</label>
					          <input type="text" class="form-control" name="name" value="<?php echo $row['name'] ?>">
					        </div>
					        <div class="form-group">
					          <label>当前库存</label>
					          <input type="text" class="form-control" name="inventory" value="<?php echo $row['inventory'] ?>">
					        </div>
					        <div class="form-group">
					          <label>安全库存</label>
					          <input type="text" class="form-control" name="safe_inventory" value="<?php echo $row['safe_inventory'] ?>">
					        </div>
					        <div class="form-group">
					          <label>商品简介</label>
					          <textarea class="form-control" rows="3" name="brief"><?php echo $row['brief'] ?></textarea>
					        </div>
				      	</div>
				     	<div class="modal-footer">
				          <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
				          <button type="submit" class="btn btn-primary">保存</button>
				        
				        </div>
				        </form>
				    </div>
				  </div>
				</div>

				<button type="button" class="btn btn-danger" data-toggle="modal" data-target=".bs-delete-modal-sm">删除</button>
				<div class="modal fade bs-delete-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-sm">
				    <div class="modal-content">
					    <div class="modal-header">
				          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				          <h4 class="modal-title" id="gridSystemModalLabel">确定要删除此商品？删除后数据将不再恢复！</h4>
				        </div>
				     	<div class="modal-footer">
				          <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
				          <a class="btn btn-warning" href="delete.php?id=<?php echo $row['goods_id'] ?>" role="button">确认删除</a>
				          
				        </div>
				    </div>
				  </div>
				</div>

			</div>
			</div>
			<hr/>
			<hr/>
			<h4 class="text-center">
				<?php echo $row['name']; ?>的库存状态
			</h4>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>
							序号
						</th>
						<th>
							入库
						</th>
						<th>
							出库
						</th>
						<th>
							日期
						</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				$query="select * from trades where goods_id=".$_GET['id']." order by updated_at desc";
				$result=$mysql->query($query);
				for ($i=1; $i <= $result->num_rows ; $i++) { 
					$row=$result->fetch_assoc();
					if ($row['number']< 0) {
						echo "<tr class='warning'><td>$i</td><td></td><td>".-$row['number']."</td><td>".$row['updated_at']."</td></tr>";
					}else{
						echo "<tr class='info'><td>$i</td><td>".$row['number']."</td><td></td><td>".$row['updated_at']."</td></tr>";
					}
				}
				 ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php 
 $mysql->close();
  }else{
  	echo "<script>window.location.href='error.php?num=2';</script>";
  }
  ?>

   <footer class="footer">
      <div class="container text-center">
        <p class="text-muted">©2015 映日飞云</p>
      </div>
    </footer>
</body>
</html>