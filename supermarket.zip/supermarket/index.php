<?php require_once 'head.php'; ?>
  <body>
<div class="container-fluid">
  <div class="row-fluid">
    <div class="jumbotron">
      <h2 class="text-center">
        库存管理系统
      </h2>
    </div>
  </div>
  <div class="row">
  <div class="col-xs-6 col-md-4" >
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">商品</h3>
        </div>
        <div class="panel-body">
          <!-- <form class="navbar-form navbar-left" role="search">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Search">
            </div>
            <button type="submit" class="btn btn-default">搜索</button>
          </form><br/><br/> -->
          <!-- 快速搜索 -->
          <input class="form-control" type="text" onkeyup="showHint(this.value)" placeholder="快速搜索">
          <ul class="list-group" id="search" style="position:absolute; z-index: 1;"></ul>

          <br/><br/>
          
          <div class="btn-group btn-group-lg btn-group-justified" role="group" aria-label="...">
            <a class="btn btn-success" href="trade.php?trade=in" role="button">入库</a>
            <a class="btn btn-primary" href="trade.php?trade=out" role="button">出库</a>
          </div>
          <br/><br/>
          <div>
            <a class="btn btn-default btn-lg btn-group-justified" href="add.php" role="button">添加商品</a>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xs-6 col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">类别</h3>
        </div>
        <div class="panel-body">
        <?php 
          //require_once 'connect.php';
          $query="select class_id,count(goods_id) from goods group by class_id order by class_id";
          $result=$mysql->query($query);
          $index=array();
          for ($i=1; $i <= $result->num_rows ; $i++) { 
            $row=$result->fetch_assoc();
            $index[$row['class_id']]=$row['count(goods_id)'];
          }
         ?>
         <div class="row text-center">
            <div class="col-md-5">
              <a class="btn btn-primary btn-lg mybtn" href="statistics.php?class_id=1" role="button">
              水产类 <span class="badge"><?php echo !empty($index['1'])?$index['1']:0; ?></span>
              </a>
            </div>
            <div class="col-md-5">
              <a class="btn btn-primary btn-lg mybtn" href="statistics.php?class_id=2" role="button">
              电器类 <span class="badge"><?php echo !empty($index['2'])?$index['2']:0; ?></span>
              </a>
            </div>
            <div class="col-md-5">
              <a class="btn btn-primary btn-lg mybtn" href="statistics.php?class_id=3" role="button">
              肉食类 <span class="badge"><?php echo !empty($index['3'])?$index['3']:0; ?></span>
              </a>
            </div>
            <div class="col-md-5">
              <a class="btn btn-primary btn-lg mybtn" href="statistics.php?class_id=4" role="button">
              鲜果类 <span class="badge"><?php echo !empty($index['4'])?$index['4']:0; ?></span>
              </a>
            </div>
            <div class="col-md-5">
              <a class="btn btn-primary btn-lg mybtn" href="statistics.php?class_id=5" role="button">
              干品类 <span class="badge"><?php echo !empty($index['5'])?$index['5']:0; ?></span>
              </a>
            </div>
            <div class="col-md-5">
              <a class="btn btn-primary btn-lg mybtn" href="statistics.php?class_id=6" role="button">
              服装类 <span class="badge"><?php echo !empty($index['6'])?$index['6']:0; ?></span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xs-6 col-md-4" >
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">统计</h3>
        </div>
        <div class="panel-body">

          <form class="form-inline" action="contents.php">
            <div class="form-group">
              <select class="form-control" name="year">
                <option>2015年</option>
              </select>
            </div>
            <div class="form-group">
              <select class="form-control" name="month">
                <option>1月</option>
                <option>2月</option>
                <option>3月</option>
                <option>4月</option>
                <option>5月</option>
                <option>6月</option>
                <option>7月</option>
                <option>8月</option>
                <option>9月</option>
                <option>10月</option>
                <option>11月</option>
                <option>12月</option>
              </select>
            </div>
            <button type="submit" class="btn btn-default">报表</button>
          </form>
          
          <br/><br/>
          <div>
            <a class="btn btn-info btn-lg btn-group-justified" href="contents.php?year=<?php echo date('Y'); ?>年" role="button">盘存</a>
          </div>
          <br/><br/>
          <?php 
            $query="select name,goods_id from goods where inventory < safe_inventory";
            $result=$mysql->query($query);
            for ($i=1; $i <= $result->num_rows ; $i++) { 
              $row=$result->fetch_assoc();
              echo "<div class='alert alert-danger' role='alert'><a class='alert-link' href='show.php?id=".$row['goods_id']."'>警告：<strong>".$row['name']."</strong>的库存量低于安全库存，请尽快入库！</a></div>";
            }
           ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once 'foot.php'; ?>
