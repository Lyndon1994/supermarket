<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<title>Error</title>
</head>
<body>
	<?php 
		switch ($_GET['num']) {
			case 1:
				echo "<h1>出错！</h1>";
				break;
			case 2:
				echo "<h1>您的地址出错啦！</h1>";
				break;
			case 3:
				echo "<h1>没有此商品！</h1>";
				break;
			default:
				# code...
				break;
		}
	 ?>
		
</body>
</html>