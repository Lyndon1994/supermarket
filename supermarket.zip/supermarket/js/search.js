function showHint(str)
{
  var xmlhttp;
  if (str.length==0)
    { 
    document.getElementById("search").innerHTML="";
    return;
    }
  if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
    }
  else
    {// code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  xmlhttp.onreadystatechange=function()
    {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
      {
      document.getElementById("search").innerHTML=xmlhttp.responseText;
      }
    }
  xmlhttp.open("GET","./search.php?q="+str,true);
  xmlhttp.send();
}

function showResults(str,show)
{
var xmlhttp;
if (str.length==0)
  { 
    $("#"+show).html("");
  //document.getElementById(show).innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
       $("#"+show).show();
       $("#"+show).html(xmlhttp.responseText);
    //document.getElementById(show).innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","./showResults.php?q="+str,true);
xmlhttp.send();
}

function autoWrite (id,name) {
  $("#goodsID").val(id);
  $("#goodsName").val(name);
}

// $(document).ready(function(){
//   $(document).click(function(){
//     $(".list-group").click(function(){
//       return;
//     })
//     $(".list-group").hide();
//   });
// });