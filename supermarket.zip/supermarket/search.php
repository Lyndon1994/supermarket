<?php 
  require_once 'connect.php';
  $query="select goods_id,name from goods where name like '%".$_GET['q']."%'";
  $result=$mysql->query($query);
  if ($result&&$result->num_rows>0) {
  	for ($i=1; $i <= $result->num_rows ; $i++) { 
	    $row=$result->fetch_assoc();
	    echo "<li class='list-group-item'><a href='show.php?id=".$row['goods_id']."'>".$row['name']."</a></li>";
	  }
  }
  else{
	echo "<li class='list-group-item'>未找到结果</li>";
  }
 ?> 