<?php 
  require_once 'connect.php';
  $query="select goods_id,name from goods where name like '%".$_GET['q']."%' or goods_id like '%".$_GET['q']."%'";
  $result=$mysql->query($query);
  if ($result&&$result->num_rows>0) {
  	for ($i=1; $i <= $result->num_rows ; $i++) { 
	    $row=$result->fetch_assoc();
	    if ($row['goods_id']==$_GET['q']||$row['name']==$_GET['q']) {
	    	echo "<script>autoWrite(\"".$row['goods_id']."\",\"".$row['name']."\");</script>";
	    }else{
	    	echo "<li class='list-group-item' onclick=\"autoWrite('".$row['goods_id']."','".$row['name']."')\">".$row['goods_id']." ".$row['name']."</li>";
	    }
	  }
  }
  else{
	echo "<li class='list-group-item'>未找到结果</li>";
  }
 ?> 