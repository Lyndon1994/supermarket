<?php require_once 'head.php'; ?>

<?php 
  if (!empty($_GET['class_id'])) {

    //require_once 'connect.php';
    
    $classId=$_GET['class_id'];//类别
    $className=array("水产类","电器类","肉食类","鲜果类","干品类","服装类");
    $class=$className[$classId-1];
    $title="";//标题
    $term="";
    if (empty($_GET['date'])) {//类别总的统计表
    	$title=$class."统计报表";
    }else{
    	$date=explode('-',$_GET['date']);
    	if (!empty($date[1])&&$date[1]!=0) {//月查询表
    		$term=" and year(updated_at) =".$date[0]." and month(updated_at)= ".$date[1];
	    	$title=$date[0]."年".$date[1]."月".$class."统计报表";
	    	
	    }else{
	    	$term=" and year(updated_at) =".$date[0];
	    	$title=$date[0]."年".$class."统计报表";
	    }
    }

	
?> 
<script>
$("title").html("<?php echo $title; ?>");
</script>
    


<body>
<div class="container-fluid">
	<div class="row-fluid">
	<ul class="nav nav-tabs nav-justified">
        <li role="presentation"><a href="./trade.php?trade=in">入库</a></li>
        <li role="presentation"><a href="./">超市库存管理系统</a></li>
        <li role="presentation"><a href="./trade.php?trade=out">出库</a></li>
      </ul>
		<div class="span12">
			<h1 class="text-center">
				<?php echo $title; ?>
			</h1>

			<table class="table table-striped table-hover">
				<thead>
		          <tr>
		            <th>
		              商品ID
		            </th>
		            <th>
		              商品名称
		            </th>
		            <th>
		              总入库
		            </th>
		            <th>
		              总出库
		            </th>
		            <th>
		              当前库存
		            </th>
		            <th>
		              期初
		            </th>
		            <th>
		            	编辑
		            </th>
		          </tr>
		        </thead>
				<tbody>
				<?php 
				$query="select distinct goods_id, name, inventory,safe_inventory, brief
			    		from goods where class_id=".$classId." order by goods_id" ;
				    
				$result=$mysql->query($query);
			    if(!$result) echo "<script>window.location.href='error.php?num=1';</script>";//查询出错

				for ($i=1; $i <= $result->num_rows ; $i++) { 
					$row=$result->fetch_assoc();
					$color="";
					if ($row['inventory']<$row['safe_inventory']) {
						$color='danger';
					}else{
						$color='';
					}
					$queryTrade="select sum(number) from trades where goods_id=".$row['goods_id'].$term." group by number >= 0";
					$trade=$mysql->query($queryTrade);
					if (empty($trade)) {
						$sumIn=0;
						$sumOut=0;
					}else{
						$tradeSum=$trade->fetch_assoc();
						if ($tradeSum['sum(number)']>0) {
							$sumIn=$tradeSum['sum(number)'];//总入库量
							$sumOut=0;
						}else{
							$sumOut=$tradeSum['sum(number)'];
							$tradeSum=$trade->fetch_assoc();
							$sumIn=$tradeSum['sum(number)'];//总入库量
						}
						
					}
						
					
					echo "<tr class=".$color."><td>".$row['goods_id']."</td><td><a href='show.php?id=".$row['goods_id']."'>".$row['name']."</a></td><td>".$sumIn."</td><td>".(-$sumOut)."</td><td>".$row['inventory']."</td><td>".(intval($row['inventory'])-$sumOut-$sumIn)."</td>";
				 ?>
					<td>
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-<?php echo $row['goods_id'] ?>-modal-sm">核对</button>
				<div class="modal fade bs-<?php echo $row['goods_id'] ?>-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-sm">
				    <div class="modal-content">
					    <div class="modal-header">
				          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				          <h4 class="modal-title" id="gridSystemModalLabel">修改商品信息</h4>
				        </div>
				       	<form action="edit.php?id=<?php echo $row['goods_id'] ?>" method="post">
				        <div class="modal-body">
					        <div class="form-group">
					          <label>商品ID</label>
					          <input type="text" class="form-control" name="goods_id" value="<?php echo $row['goods_id'] ?>" readonly>
					        </div>
					        <div class="form-group">
					          <label>商品名称</label>
					          <input type="text" class="form-control" name="name" value="<?php echo $row['name'] ?>">
					        </div>
					        <div class="form-group">
					          <label>当前库存</label>
					          <input type="text" class="form-control" name="inventory" value="<?php echo $row['inventory'] ?>">
					        </div>
					        <div class="form-group">
					          <label>安全库存</label>
					          <input type="text" class="form-control" name="safe_inventory" value="<?php echo $row['safe_inventory'] ?>">
					        </div>
					        <div class="form-group">
					          <label>商品简介</label>
					          <textarea class="form-control" rows="3" name="brief"><?php echo $row['brief'] ?></textarea>
					        </div>
				      	</div>
				     	<div class="modal-footer">
				          <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
				          <button type="submit" class="btn btn-primary">保存</button>
				        
				        </div>
				        </form>
				    </div>
				  </div>
				</div>
					</td>


					</tr>
				<?php 	
				}
				 ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php 
 $mysql->close();
  }else{
  	echo "<script>window.location.href='error.php?num=2';</script>";
  }
  ?>
<?php require_once 'foot.php'; ?>

